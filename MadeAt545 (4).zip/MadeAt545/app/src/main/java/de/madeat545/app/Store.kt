package de.madeat545.app

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import java.time.LocalDate

/**
 * Lokale Speicherung. Jede Änderung erhöht [version]; alle Lese-Funktionen lesen
 * [version] mit – dadurch aktualisiert sich die Oberfläche sofort nach dem Abhaken.
 */
class Store(context: Context) {
    companion object {
        val version = mutableIntStateOf(0)
    }

    private val p = context.applicationContext.getSharedPreferences("made545", Context.MODE_PRIVATE)

    init {
        if (!p.contains("start_date")) {
            p.edit().putString("start_date", LocalDate.now().toString()).apply()
        }
    }

    private fun touch() { version.intValue = version.intValue + 1 }
    private fun observe() { version.intValue }

    val startDate: LocalDate
        get() = LocalDate.parse(p.getString("start_date", LocalDate.now().toString()))

    // ---------- Abhaken ----------
    fun done(date: LocalDate): Set<String> {
        observe()
        return p.getStringSet("done_$date", emptySet())?.toSet() ?: emptySet()
    }

    fun isDone(date: LocalDate, id: String) = id in done(date)

    fun setDone(date: LocalDate, id: String, value: Boolean) {
        val s = done(date).toMutableSet()
        if (value) s.add(id) else s.remove(id)
        p.edit().putStringSet("done_$date", s).apply()
        touch()
    }

    // ---------- Woche / Rezepte ----------
    var weekOffset: Int
        get() { observe(); return p.getInt("week_offset", 0) }
        set(v) { p.edit().putInt("week_offset", v).apply(); touch() }

    fun recipeIndex(date: LocalDate): Int {
        observe()
        return p.getInt("recipe_$date", Math.floorMod(date.toEpochDay(), Recipes.all.size.toLong()).toInt())
    }

    fun setRecipeIndex(date: LocalDate, i: Int) {
        p.edit().putInt("recipe_$date", Math.floorMod(i, Recipes.all.size)).apply()
        touch()
    }

    // ---------- Stundenplan ----------
    fun timetables(): List<Timetable> {
        observe()
        val list = TimetableJson.fromJson(p.getString("timetables", null))
        return if (list.isEmpty()) listOf(Timetable.DEFAULT) else list.sortedBy { it.validFrom }
    }

    /** Der Stundenplan, der an [date] gilt. */
    fun timetableFor(date: LocalDate): Timetable =
        timetables().lastOrNull { !it.validFrom.isAfter(date) } ?: timetables().first()

    /** Neuen Stundenplan speichern. Ein Plan mit gleichem Startdatum wird ersetzt. */
    fun saveTimetable(t: Timetable) {
        val list = timetables().filter { it.validFrom != t.validFrom } + t
        p.edit().putString("timetables", TimetableJson.toJson(list.sortedBy { it.validFrom })).apply()
        touch()
    }

    /** Zukünftigen (noch nicht aktiven) Plan verwerfen. */
    fun deleteTimetable(validFrom: LocalDate) {
        val list = timetables().filter { it.validFrom != validFrom }
        p.edit().putString("timetables", TimetableJson.toJson(list)).apply()
        touch()
    }

    // ---------- To-Dos & Termine ----------
    fun todos(): List<Todo> {
        observe()
        return Todo.listFromJson(p.getString("todos", null))
    }

    private fun saveTodos(list: List<Todo>) {
        p.edit().putString("todos", Todo.listToJson(list)).apply()
        touch()
    }

    fun upsertTodo(t: Todo) {
        saveTodos(todos().filter { it.id != t.id } + t)
    }

    fun deleteTodo(id: Long) {
        saveTodos(todos().filter { it.id != id })
    }

    /** Abhaken: wiederkehrende Einträge springen auf den nächsten Termin. */
    fun completeTodo(t: Todo, value: Boolean): Todo {
        val updated = if (value && t.repeat != Repeat.NONE && t.date != null) {
            t.copy(date = t.nextOccurrence(), done = false)
        } else {
            t.copy(done = value)
        }
        upsertTodo(updated)
        return updated
    }

    // ---------- Plan & Streak ----------
    fun plan(date: LocalDate): DayPlan = Schedule.dayPlan(date, weekOffset, timetableFor(date))

    fun isComplete(date: LocalDate): Boolean {
        val plan = plan(date)
        val done = done(date)
        return plan.items.filter { it.mandatory }.all { it.id in done }
    }

    fun progress(date: LocalDate): Float {
        val items = plan(date).items
        if (items.isEmpty()) return 0f
        val done = done(date)
        return items.count { it.id in done }.toFloat() / items.size
    }

    /**
     * Streak = Schultage in Folge mit allen Pflicht-Aufgaben.
     * Wochenenden und Ferien pausieren (zählen nicht, brechen nicht).
     * Heute zählt, sobald alles erledigt ist; ein offener heutiger Tag bricht nicht.
     */
    fun streak(today: LocalDate): Int = streakWhere(today) { d -> isComplete(d) }

    /** Einzel-Streak für eine Aufgabe (z. B. "bett"). Tage ohne diese Aufgabe werden übersprungen. */
    fun itemStreak(today: LocalDate, id: String): Int = streakWhere(today, skip = { d -> plan(d).items.none { it.id == id } }) { d ->
        id in done(d)
    }

    private fun streakWhere(today: LocalDate, skip: (LocalDate) -> Boolean = { false }, ok: (LocalDate) -> Boolean): Int {
        var count = 0
        if (Schedule.isSchoolDay(today) && !skip(today) && ok(today)) count++
        var d = today.minusDays(1)
        val start = startDate
        repeat(800) {
            if (d.isBefore(start)) return count
            if (Schedule.isSchoolDay(d) && !skip(d)) {
                if (ok(d)) count++ else return count
            }
            d = d.minusDays(1)
        }
        return count
    }

    /** Längster Streak seit Start der App. */
    fun longestStreak(today: LocalDate): Int {
        var best = 0
        var run = 0
        var d = startDate
        while (!d.isAfter(today)) {
            if (Schedule.isSchoolDay(d)) {
                if (isComplete(d)) {
                    run++
                    if (run > best) best = run
                } else if (d.isBefore(today)) {
                    run = 0
                }
            }
            d = d.plusDays(1)
        }
        return best
    }
}
