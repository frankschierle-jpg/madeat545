package de.madeat545.app

import java.time.DayOfWeek
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime
import java.time.temporal.TemporalAdjusters

enum class WeekType { A, B }
enum class DayKind { SCHOOL, WEEKEND, HOLIDAY }

/** Ein Eintrag im Tagesplan. [time] nur bei festen Zeiten (Morgen/Abend). */
data class PlanItem(
    val id: String,
    val title: String,
    val time: String? = null,
    val note: String? = null,
    val mandatory: Boolean = false,
    val isLunch: Boolean = false,
    val isBed: Boolean = false,
)

data class DayPlan(
    val date: LocalDate,
    val kind: DayKind,
    val week: WeekType?,
    val holidayName: String?,
    val items: List<PlanItem>,
)

data class Holiday(val name: String, val from: LocalDate, val to: LocalDate)

/** Feste Freizeittermine (gleich in A- und B-Woche). */
data class Activity(
    val day: DayOfWeek,
    val id: String,
    val title: String,
    val start: LocalTime,
    val end: LocalTime,
    val travelMin: Int,
    val isSport: Boolean,
    val isOrchestra: Boolean = false,
)

/** Stundenplan: Schulende pro Wochentag, getrennt für A- und B-Woche. */
data class Timetable(
    val validFrom: LocalDate,
    val endA: Map<DayOfWeek, LocalTime>,
    val endB: Map<DayOfWeek, LocalTime>,
    val travelMin: Int = 25,
) {
    fun endFor(week: WeekType, day: DayOfWeek): LocalTime? = if (week == WeekType.A) endA[day] else endB[day]

    companion object {
        private fun t(s: String) = LocalTime.parse(s)
        /** Stundenplan, den du mir genannt hast (gilt seit Schuljahresbeginn). */
        val DEFAULT = Timetable(
            validFrom = LocalDate.of(2026, 8, 17),
            endA = mapOf(
                DayOfWeek.MONDAY to t("14:00"), DayOfWeek.TUESDAY to t("15:35"), DayOfWeek.WEDNESDAY to t("14:00"),
                DayOfWeek.THURSDAY to t("15:35"), DayOfWeek.FRIDAY to t("14:00"),
            ),
            endB = mapOf(
                DayOfWeek.MONDAY to t("15:35"), DayOfWeek.TUESDAY to t("15:35"), DayOfWeek.WEDNESDAY to t("15:35"),
                DayOfWeek.THURSDAY to t("14:00"), DayOfWeek.FRIDAY to t("14:00"),
            ),
            travelMin = 25,
        )
    }
}

object Schedule {
    val WAKE_TIME: LocalTime = LocalTime.of(5, 45)
    private val SLEEP_PREP: Int = 21 * 60 + 30 // ab 21:30 runterfahren, 22:00 schlafen
    val REST_DAY: DayOfWeek = DayOfWeek.WEDNESDAY // Orchester-Tag = Ruhetag für Abendsport

    /** Montag einer bekannten A-Woche (28.09.–02.10.2026). */
    private val REFERENCE_A_MONDAY: LocalDate = LocalDate.of(2026, 9, 28)

    /** Schulferien Sachsen 2026/27 (Quelle: schule.sachsen.de). */
    val holidays = listOf(
        Holiday("Herbstferien", LocalDate.of(2026, 10, 12), LocalDate.of(2026, 10, 24)),
        Holiday("Weihnachtsferien", LocalDate.of(2026, 12, 23), LocalDate.of(2027, 1, 2)),
        Holiday("Winterferien", LocalDate.of(2027, 2, 8), LocalDate.of(2027, 2, 19)),
        Holiday("Osterferien", LocalDate.of(2027, 3, 26), LocalDate.of(2027, 4, 2)),
        Holiday("Unterrichtsfreier Tag", LocalDate.of(2027, 5, 7), LocalDate.of(2027, 5, 7)),
        Holiday("Pfingstferien", LocalDate.of(2027, 5, 15), LocalDate.of(2027, 5, 18)),
        Holiday("Sommerferien", LocalDate.of(2027, 7, 10), LocalDate.of(2027, 8, 20)),
    )

    val activities = listOf(
        Activity(DayOfWeek.MONDAY, "geigenunterricht", "Geigenunterricht", LocalTime.of(18, 45), LocalTime.of(19, 15), 15, isSport = false),
        Activity(DayOfWeek.TUESDAY, "abendsport", "Ballett", LocalTime.of(17, 30), LocalTime.of(18, 30), 30, isSport = true),
        Activity(DayOfWeek.WEDNESDAY, "orchester", "Orchester", LocalTime.of(17, 30), LocalTime.of(20, 0), 30, isSport = false, isOrchestra = true),
        Activity(DayOfWeek.THURSDAY, "abendsport", "Volleyball", LocalTime.of(17, 0), LocalTime.of(19, 30), 30, isSport = true),
        Activity(DayOfWeek.FRIDAY, "abendsport", "Volleyball", LocalTime.of(16, 0), LocalTime.of(17, 30), 15, isSport = true),
    )

    fun activityOn(day: DayOfWeek): Activity? = activities.firstOrNull { it.day == day }

    fun holidayOn(d: LocalDate): Holiday? =
        holidays.firstOrNull { !d.isBefore(it.from) && !d.isAfter(it.to) }

    fun dayKind(d: LocalDate): DayKind = when {
        holidayOn(d) != null -> DayKind.HOLIDAY
        d.dayOfWeek == DayOfWeek.SATURDAY || d.dayOfWeek == DayOfWeek.SUNDAY -> DayKind.WEEKEND
        else -> DayKind.SCHOOL
    }

    fun isSchoolDay(d: LocalDate): Boolean = dayKind(d) == DayKind.SCHOOL

    private fun weekHasSchool(monday: LocalDate): Boolean =
        (0L..4L).any { isSchoolDay(monday.plusDays(it)) }

    /** A/B wechselt nur in Wochen mit Schule – Ferienwochen zählen nicht mit. */
    fun weekType(d: LocalDate, offset: Int): WeekType {
        val monday = d.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY))
        var count = 0
        var m = REFERENCE_A_MONDAY
        if (!monday.isBefore(REFERENCE_A_MONDAY)) {
            while (m.isBefore(monday)) {
                if (weekHasSchool(m)) count++
                m = m.plusWeeks(1)
            }
        } else {
            while (m.isAfter(monday)) {
                m = m.minusWeeks(1)
                if (weekHasSchool(m)) count--
            }
        }
        return if (Math.floorMod(count + offset, 2) == 0) WeekType.A else WeekType.B
    }

    // ---------- feste Bausteine ----------
    private fun bett() = PlanItem("bett", "Aufstehen & Bett machen", "05:45", "wird mit dem Bett-Foto abgehakt", mandatory = true, isBed = true)
    private fun morgensport() = PlanItem("morgensport", "Morgensport", "06:00–07:00", mandatory = true)
    private fun fruehstueck() = PlanItem("fruehstueck", "Duschen & Frühstück", "07:00")
    private fun schlafen() = PlanItem("schlafen", "Schlafen gehen", "22:00")

    fun duration(min: Int): String {
        val h = min / 60
        val m = min % 60
        return when {
            h == 0 -> "ca. $m Min."
            m == 0 -> "ca. $h Std."
            m == 30 -> "ca. $h,5 Std."
            else -> "ca. $h Std. $m Min."
        }
    }

    private fun mins(t: LocalTime) = t.hour * 60 + t.minute

    /**
     * Plant den Nachmittag automatisch aus Schulende + festen Freizeitterminen.
     * Ergebnis: Reihenfolge der Aufgaben (ohne Uhrzeiten).
     */
    fun afternoon(schoolEnd: LocalTime, travelHome: Int, day: DayOfWeek): List<PlanItem> {
        val items = mutableListOf<PlanItem>()
        val longDay = schoolEnd.isAfter(LocalTime.of(14, 59))
        val home = mins(schoolEnd) + travelHome
        val act = activityOn(day)

        items += PlanItem("schule", "Schule", note = "bis ${schoolEnd} · ca. ${minutesToTime(home)} zu Hause")
        var cursor: Int
        if (longDay) {
            items += PlanItem("mittag", "Mittagessen", note = "in der Schule / mitgebracht", mandatory = true, isLunch = true)
            items += PlanItem("snack", "Snack")
            cursor = home + 15
        } else {
            items += PlanItem("mittag", "Mittagessen", note = "Rezeptvorschlag unten", mandatory = true, isLunch = true)
            cursor = home + 30
        }

        // Zeitfenster bestimmen
        data class Window(var start: Int, val end: Int) { val len get() = (end - start).coerceAtLeast(0) }
        val windows = mutableListOf<Pair<String, Window>>() // Marker, was nach dem Fenster kommt
        val leave = act?.let { mins(it.start) - it.travelMin }
        val back = act?.let { mins(it.end) + it.travelMin }

        val needSport = act?.isSport != true && day != REST_DAY
        val needViolin = act?.isOrchestra != true

        if (act == null) {
            windows += "dinner" to Window(cursor, 18 * 60 + 30)
            windows += "end" to Window(19 * 60, SLEEP_PREP)
        } else if (leave!! >= 18 * 60 + 15) {
            // Abendessen vor dem Losgehen
            windows += "dinner_then_act" to Window(cursor, leave - 30)
            windows += "end" to Window(back!!, SLEEP_PREP)
        } else if (back!! < 18 * 60) {
            windows += "act" to Window(cursor, leave)
            windows += "dinner" to Window(back, 18 * 60 + 30)
            windows += "end" to Window(19 * 60, SLEEP_PREP)
        } else {
            windows += "act" to Window(cursor, leave)
            windows += "dinner_after" to Window(back + 30, SLEEP_PREP)
        }

        var learned = 0
        var sportDone = !needSport
        var violinDone = !needViolin
        var lernenNr = 1
        val target = 120

        fun addLearn(min: Int) {
            if (min < 20) return
            items += PlanItem("lernen$lernenNr", "Lernen", note = duration(min))
            lernenNr++
            learned += min
        }
        fun addSport() {
            items += PlanItem("abendsport", "Kurzes Training", note = "Abendsport · 30 Min.", mandatory = true)
            sportDone = true
        }
        fun addViolin() {
            items += PlanItem("geige_ueben", "Geige üben", note = "30 Min.")
            violinDone = true
        }
        fun addActivity() {
            val a = act ?: return
            items += PlanItem(
                a.id, a.title,
                note = (if (a.isSport) "Abendsport · " else "") + "Erinnerung zum Losgehen kommt",
                mandatory = a.isSport,
            )
        }
        fun dinner() { items += PlanItem("abendessen", "Abendessen") }

        windows.forEachIndexed { index, (marker, w) ->
            val isLast = index == windows.lastIndex
            var free = w.len
            val first = index == 0
            val needLearn = (60 - learned).coerceAtLeast(0)
            val buffer = if (isLast && free - needLearn >= 60) 30 else 0
            val extras = (if (!sportDone) 30 else 0) + (if (!violinDone) 30 else 0)
            val reserve = if (free - extras - buffer >= maxOf(needLearn, if (first) 45 else 0)) extras else 0
            fun placeExtras(budget: Int) {
                var b = budget
                if (!violinDone && b >= 30 && free >= 30) { addViolin(); free -= 30; b -= 30 }
                if (!sportDone && b >= 30 && free >= 30) { addSport(); free -= 30; b -= 30 }
            }
            // Nach der Schule zuerst lernen (Kopf noch frisch), später zuerst Geige/Training
            if (!first) placeExtras(reserve)
            val learn = minOf(target - learned, free - (if (first) reserve else 0) - buffer)
            if (learn >= 20) {
                addLearn(learn)
                free -= learn
            }
            if (first) placeExtras(reserve)
            if (isLast && learned < 60 && free >= 20) {
                val l = minOf(free, maxOf(60 - learned, 20))
                addLearn(l)
                free -= l
            }
            when (marker) {
                "dinner" -> dinner()
                "dinner_then_act" -> { dinner(); addActivity() }
                "act" -> addActivity()
                "dinner_after" -> { /* Abendessen kam schon vor dem Fenster */ }
            }
            // Sonderfall: Abendessen nach Rückkehr kommt VOR dem letzten Fenster
            if (index + 1 < windows.size && windows[index + 1].first == "dinner_after") dinner()
        }
        if (!violinDone && needViolin) { /* kein Platz – heute ohne Geige üben */ }
        return items
    }

    private fun minutesToTime(m: Int): String = "%02d:%02d".format(m / 60, m % 60)

    private fun freeDay() = listOf(
        PlanItem("frei_sport", "Sport", note = "freiwillig"),
        PlanItem("frei_lernen", "Lernen", note = "freiwillig"),
        PlanItem("frei_geige", "Geige üben", note = "freiwillig"),
    )

    fun dayPlan(d: LocalDate, offset: Int, timetable: Timetable): DayPlan {
        val kind = dayKind(d)
        return when (kind) {
            DayKind.SCHOOL -> {
                val week = weekType(d, offset)
                val end = timetable.endFor(week, d.dayOfWeek) ?: LocalTime.of(15, 35)
                val items = listOf(bett(), morgensport(), fruehstueck()) +
                    afternoon(end, timetable.travelMin, d.dayOfWeek) + schlafen()
                DayPlan(d, kind, week, null, items)
            }
            DayKind.WEEKEND -> DayPlan(d, kind, null, null, freeDay())
            DayKind.HOLIDAY -> DayPlan(d, kind, null, holidayOn(d)?.name, freeDay())
        }
    }

    // ---------- Losgehen-Erinnerungen ----------
    fun nextWake(now: LocalDateTime): LocalDateTime? {
        var d = now.toLocalDate()
        repeat(400) {
            if (isSchoolDay(d)) {
                val t = d.atTime(WAKE_TIME)
                if (t.isAfter(now)) return t
            }
            d = d.plusDays(1)
        }
        return null
    }

    fun nextLeave(now: LocalDateTime): Pair<LocalDateTime, String>? {
        var d = now.toLocalDate()
        repeat(30) {
            val a = activityOn(d.dayOfWeek)
            if (a != null && isSchoolDay(d)) {
                val t = d.atTime(a.start.minusMinutes(a.travelMin.toLong()))
                if (t.isAfter(now)) return t to "Zeit zum Losgehen: ${a.title} um ${a.start}"
            }
            d = d.plusDays(1)
        }
        return null
    }
}
