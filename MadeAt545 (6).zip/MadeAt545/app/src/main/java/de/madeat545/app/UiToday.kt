package de.madeat545.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun TodayScreen(host: MainActivity) {
    val store = host.store
    val today = LocalDate.now()
    val plan = store.plan(today)
    val done = store.done(today)
    val streak = store.streak(today)
    val progress = store.progress(today)
    val dateText = today.format(DateTimeFormatter.ofPattern("EEEE, d. MMMM", Locale.GERMAN))
    val badge = when (plan.kind) {
        DayKind.SCHOOL -> "${plan.week}-Woche"
        DayKind.WEEKEND -> "Wochenende"
        DayKind.HOLIDAY -> plan.holidayName ?: "Ferien"
    }
    val dueTodos = store.todos()
        .filter { !it.done && it.date != null && !it.date.isAfter(today) }
        .sortedWith(compareBy<Todo>({ it.date }, { it.time ?: java.time.LocalTime.MAX }))

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Text("Made at 5:45", fontFamily = FontFamily.Serif, fontSize = 15.sp, color = C.MokkaLight)
        Spacer(Modifier.height(4.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(dateText, fontFamily = FontFamily.Serif, fontSize = 26.sp, color = C.Mokka, modifier = Modifier.weight(1f))
            Pill(badge)
        }
        Spacer(Modifier.height(16.dp))

        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StreakRing(progress = progress, size = 92, label = "$streak", sub = if (streak == 1) "Tag" else "Tage")
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text("Streak", fontWeight = FontWeight.Medium, color = C.Mokka, fontSize = 17.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        when {
                            plan.kind != DayKind.SCHOOL -> "Heute pausiert dein Streak – er reißt nicht."
                            store.isComplete(today) -> "Alle Pflicht-Aufgaben erledigt. Stark!"
                            else -> "Noch offen: " + plan.items.filter { it.mandatory && it.id !in done }.joinToString(", ") { it.title }
                        },
                        color = C.MokkaLight, fontSize = 14.sp,
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "„${Quotes.forDay(today)}“",
            fontFamily = FontFamily.Serif, color = C.MokkaLight, fontSize = 15.sp,
            modifier = Modifier.padding(horizontal = 4.dp),
        )
        Spacer(Modifier.height(16.dp))

        if (dueTodos.isNotEmpty()) {
            Label("Heute fällig")
            Spacer(Modifier.height(8.dp))
            dueTodos.forEach { t ->
                TodoRow(t, today, onCheck = { host.completeTodo(t, true) }, onClick = { host.tab.intValue = 1 })
                Spacer(Modifier.height(8.dp))
            }
            Spacer(Modifier.height(8.dp))
            Label("Tagesplan")
            Spacer(Modifier.height(8.dp))
        }

        if (plan.kind != DayKind.SCHOOL) {
            Hint("Heute ist frei: kein Wecker, keine Pflicht. Alles hier ist freiwillig.")
            Spacer(Modifier.height(10.dp))
        }

        plan.items.forEach { item ->
            val isDone = item.id in done
            TaskRow(item, isDone) {
                if (item.isBed && !isDone) host.takeBedPhoto()
                else host.toggle(today, item.id, !isDone)
            }
            if (item.isLunch && item.note != "in der Schule / mitgebracht") {
                RecipeCard(Recipes.forDay(store, today)) { host.nextRecipe(today) }
            }
            Spacer(Modifier.height(8.dp))
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
fun TaskRow(item: PlanItem, done: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (done) C.Beige.copy(alpha = 0.55f) else C.Beige)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CheckCircle(done)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                item.title,
                color = if (done) C.MokkaLight else C.Mokka,
                fontSize = 16.sp,
                fontWeight = if (item.mandatory) FontWeight.Medium else FontWeight.Normal,
                textDecoration = if (done) TextDecoration.LineThrough else null,
            )
            val note = item.note
            if (note != null && !(item.isBed && done)) Text(note, color = C.MokkaLight, fontSize = 13.sp)
        }
        val time = item.time
        if (time != null) Text(time, color = C.Mokka, fontSize = 14.sp, fontFamily = FontFamily.Serif)
    }
}

@Composable
fun RecipeCard(r: Recipe, onNext: () -> Unit) {
    Spacer(Modifier.height(6.dp))
    Column(
        Modifier
            .fillMaxWidth()
            .padding(start = 20.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(C.Creme)
            .border(1.dp, C.Line, RoundedCornerShape(18.dp))
            .padding(16.dp)
    ) {
        Text("Vorschlag: ${r.name}", fontFamily = FontFamily.Serif, fontSize = 17.sp, color = C.Mokka)
        Text("${r.minutes} Min. · ca. ${r.kcal} kcal", color = C.MokkaLight, fontSize = 13.sp)
        Spacer(Modifier.height(8.dp))
        Text("Zutaten", fontWeight = FontWeight.Medium, color = C.Mokka, fontSize = 14.sp)
        r.ingredients.forEach { Text("• $it", color = C.Mokka, fontSize = 14.sp) }
        Spacer(Modifier.height(6.dp))
        Text("So geht's", fontWeight = FontWeight.Medium, color = C.Mokka, fontSize = 14.sp)
        r.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", color = C.Mokka, fontSize = 14.sp) }
        Spacer(Modifier.height(10.dp))
        ActionChip("Anderer Vorschlag", color = C.Rose) { onNext() }
    }
}
