package de.madeat545.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MCard(content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(C.Beige)
            .padding(18.dp)
    ) { content() }
}

@Composable
fun Pill(text: String, color: Color = C.Rose) {
    Text(
        text,
        color = C.Mokka, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .background(color)
            .padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
fun ActionChip(text: String, color: Color = C.Sand, onClick: () -> Unit) {
    Text(
        text,
        color = C.Mokka, fontSize = 14.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(color)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 10.dp),
    )
}

@Composable
fun Title(text: String) {
    Text(text, fontFamily = FontFamily.Serif, fontSize = 26.sp, color = C.Mokka)
}

@Composable
fun Label(text: String) {
    Text(text, fontWeight = FontWeight.Medium, color = C.Mokka, fontSize = 16.sp)
}

@Composable
fun Hint(text: String) {
    Text(text, color = C.MokkaLight, fontSize = 13.sp)
}

/** Auswahl-Chips (eine Option aktiv). */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun <T> Choice(options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { (value, label) ->
            val on = value == selected
            Text(
                label,
                color = C.Mokka, fontSize = 14.sp,
                fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                modifier = Modifier
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (on) C.Sand else C.Creme)
                    .border(1.dp, if (on) C.Sand else C.Line, RoundedCornerShape(14.dp))
                    .clickable { onSelect(value) }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
            )
        }
    }
}

/** Ring wie im Logo: füllt sich mit dem Tagesfortschritt. */
@Composable
fun StreakRing(progress: Float, size: Int, label: String, sub: String?, track: Color = C.Creme) {
    Box(Modifier.size(size.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size.dp)) {
            val stroke = this.size.minDimension * 0.09f
            val inset = stroke / 2f
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(
                color = track, startAngle = 0f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke),
            )
            drawArc(
                color = C.Sand, startAngle = -90f, sweepAngle = 360f * progress.coerceIn(0f, 1f), useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = Stroke(stroke, cap = StrokeCap.Round),
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, fontFamily = FontFamily.Serif, fontSize = (size / 3.6).sp, color = C.Mokka, textAlign = TextAlign.Center)
            if (sub != null) Text(sub, fontSize = 12.sp, color = C.MokkaLight)
        }
    }
}

@Composable
fun CheckCircle(done: Boolean) {
    Box(
        Modifier
            .size(26.dp)
            .clip(RoundedCornerShape(13.dp))
            .background(if (done) C.Sand else Color.Transparent)
            .border(2.dp, C.Sand, RoundedCornerShape(13.dp)),
        contentAlignment = Alignment.Center,
    ) {
        if (done) Text("✓", color = C.Mokka, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}
