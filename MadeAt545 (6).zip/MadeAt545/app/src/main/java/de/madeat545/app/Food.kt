package de.madeat545.app

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.time.LocalDate

enum class Meal(val label: String) { BREAKFAST("Frühstück"), LUNCH("Mittagessen"), SNACK("Snack"), DINNER("Abendessen") }

/** Nährwerte pro 100 g. */
data class Food(
    val name: String,
    val kcal: Double,
    val protein: Double,
    val carbs: Double,
    val fat: Double,
    val sugar: Double = 0.0,
    val fiber: Double = 0.0,
    val servingGrams: Double = 100.0,
    val source: String = "",
)

data class FoodEntry(
    val id: Long,
    val date: LocalDate,
    val meal: Meal,
    val food: Food,
    val grams: Double,
    val photo: String? = null,
) {
    private val f get() = grams / 100.0
    val kcal get() = food.kcal * f
    val protein get() = food.protein * f
    val carbs get() = food.carbs * f
    val fat get() = food.fat * f
    val sugar get() = food.sugar * f
    val fiber get() = food.fiber * f

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("date", date.toString()); put("meal", meal.name); put("grams", grams)
        put("photo", photo ?: "")
        put("name", food.name); put("kcal", food.kcal); put("protein", food.protein)
        put("carbs", food.carbs); put("fat", food.fat); put("sugar", food.sugar); put("fiber", food.fiber)
        put("source", food.source)
    }

    companion object {
        fun fromJson(o: JSONObject) = FoodEntry(
            id = o.getLong("id"),
            date = LocalDate.parse(o.getString("date")),
            meal = runCatching { Meal.valueOf(o.getString("meal")) }.getOrDefault(Meal.SNACK),
            food = Food(
                o.optString("name"), o.optDouble("kcal", 0.0), o.optDouble("protein", 0.0),
                o.optDouble("carbs", 0.0), o.optDouble("fat", 0.0), o.optDouble("sugar", 0.0),
                o.optDouble("fiber", 0.0), source = o.optString("source"),
            ),
            grams = o.optDouble("grams", 100.0),
            photo = o.optString("photo").ifEmpty { null },
        )

        fun listToJson(l: List<FoodEntry>) = JSONArray().apply { l.forEach { put(it.toJson()) } }.toString()
        fun listFromJson(s: String?): List<FoodEntry> {
            if (s.isNullOrEmpty()) return emptyList()
            return try {
                val a = JSONArray(s)
                (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
            } catch (_: Exception) { emptyList() }
        }
    }
}

/** Häufige Lebensmittel (Durchschnittswerte pro 100 g) – funktionieren auch ohne Internet. */
object BasicFoods {
    val all = listOf(
        Food("Apfel", 52.0, 0.3, 12.0, 0.2, 10.0, 2.4, 150.0, "Basis"),
        Food("Banane", 89.0, 1.1, 20.0, 0.3, 12.0, 2.6, 120.0, "Basis"),
        Food("Orange", 47.0, 0.9, 9.0, 0.1, 9.0, 2.4, 150.0, "Basis"),
        Food("Erdbeeren", 32.0, 0.7, 5.5, 0.4, 4.9, 2.0, 150.0, "Basis"),
        Food("Ei (gekocht)", 155.0, 13.0, 1.1, 11.0, 1.1, 0.0, 60.0, "Basis"),
        Food("Haferflocken", 372.0, 13.5, 58.7, 7.0, 0.7, 10.0, 50.0, "Basis"),
        Food("Vollkornbrot", 220.0, 7.5, 38.0, 1.5, 3.0, 7.5, 50.0, "Basis"),
        Food("Toastbrot", 265.0, 8.0, 48.0, 3.5, 4.5, 3.0, 25.0, "Basis"),
        Food("Reis (gekocht)", 130.0, 2.7, 28.0, 0.3, 0.1, 0.4, 150.0, "Basis"),
        Food("Nudeln (gekocht)", 150.0, 5.5, 30.0, 0.9, 0.6, 1.8, 180.0, "Basis"),
        Food("Kartoffeln (gekocht)", 72.0, 2.0, 15.0, 0.1, 0.8, 1.8, 200.0, "Basis"),
        Food("Magerquark", 67.0, 12.0, 4.0, 0.3, 4.0, 0.0, 250.0, "Basis"),
        Food("Naturjoghurt 1,5 %", 47.0, 3.5, 4.5, 1.5, 4.5, 0.0, 150.0, "Basis"),
        Food("Milch 1,5 %", 47.0, 3.4, 4.8, 1.5, 4.8, 0.0, 200.0, "Basis"),
        Food("Gouda", 356.0, 25.0, 0.0, 28.0, 0.0, 0.0, 30.0, "Basis"),
        Food("Mozzarella light", 165.0, 19.0, 1.0, 9.0, 1.0, 0.0, 60.0, "Basis"),
        Food("Hähnchenbrust", 110.0, 23.0, 0.0, 1.5, 0.0, 0.0, 150.0, "Basis"),
        Food("Thunfisch (eigener Saft)", 110.0, 25.0, 0.0, 1.0, 0.0, 0.0, 130.0, "Basis"),
        Food("Linsen (Dose)", 85.0, 6.5, 12.0, 0.5, 1.0, 4.5, 200.0, "Basis"),
        Food("Gurke", 12.0, 0.6, 1.8, 0.1, 1.7, 0.5, 150.0, "Basis"),
        Food("Tomate", 18.0, 0.9, 2.6, 0.2, 2.6, 1.2, 120.0, "Basis"),
        Food("Paprika", 26.0, 1.0, 4.6, 0.3, 4.2, 2.1, 150.0, "Basis"),
        Food("Brokkoli", 34.0, 2.8, 4.0, 0.4, 1.7, 2.6, 200.0, "Basis"),
        Food("Möhre", 41.0, 0.9, 7.6, 0.2, 4.7, 2.8, 100.0, "Basis"),
        Food("Salat (gemischt)", 15.0, 1.3, 1.5, 0.2, 1.0, 1.3, 80.0, "Basis"),
        Food("Butter", 741.0, 0.7, 0.6, 83.0, 0.6, 0.0, 10.0, "Basis"),
        Food("Olivenöl", 884.0, 0.0, 0.0, 100.0, 0.0, 0.0, 10.0, "Basis"),
        Food("Nüsse (gemischt)", 610.0, 20.0, 13.0, 53.0, 4.0, 7.0, 30.0, "Basis"),
    )

    fun search(q: String): List<Food> {
        val s = q.trim().lowercase()
        if (s.isEmpty()) return emptyList()
        return all.filter { it.name.lowercase().contains(s) }
    }
}

/** Open Food Facts: freie Lebensmittel-Datenbank (ohne Konto, ohne Kosten). */
object OpenFoodFacts {
    private const val UA = "MadeAt545/2.1 (Android; private app)"
    private const val FIELDS = "code,product_name,product_name_de,brands,nutriments,serving_quantity"

    private fun get(url: String): JSONObject {
        val c = URL(url).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", UA)
        c.connectTimeout = 10_000
        c.readTimeout = 15_000
        try {
            val text = c.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(text)
        } finally {
            c.disconnect()
        }
    }

    private fun parse(p: JSONObject): Food? {
        val n = p.optJSONObject("nutriments") ?: return null
        val kcal = n.optDouble("energy-kcal_100g", Double.NaN).let {
            if (it.isNaN()) n.optDouble("energy_100g", Double.NaN) / 4.184 else it
        }
        if (kcal.isNaN()) return null
        fun str(k: String) = if (p.isNull(k)) "" else p.optString(k).trim()
        val name = str("product_name_de").ifBlank { str("product_name") }.ifBlank { return null }
        val brand = str("brands").split(",").firstOrNull()?.trim().orEmpty()
        return Food(
            name = if (brand.isNotEmpty()) "$name ($brand)" else name,
            kcal = kcal,
            protein = n.optDouble("proteins_100g", 0.0),
            carbs = n.optDouble("carbohydrates_100g", 0.0),
            fat = n.optDouble("fat_100g", 0.0),
            sugar = n.optDouble("sugars_100g", 0.0),
            fiber = n.optDouble("fiber_100g", 0.0),
            servingGrams = p.optDouble("serving_quantity", 100.0).takeIf { it > 0 && !it.isNaN() } ?: 100.0,
            source = "Open Food Facts",
        )
    }

    /** Muss im Hintergrund aufgerufen werden. */
    fun byBarcode(code: String): Food? = try {
        val o = get("https://world.openfoodfacts.org/api/v2/product/$code.json?fields=$FIELDS")
        if (o.optInt("status") == 1) o.optJSONObject("product")?.let { parse(it) } else null
    } catch (_: Exception) { null }

    /** Muss im Hintergrund aufgerufen werden. */
    fun search(q: String): List<Food> = try {
        val enc = URLEncoder.encode(q, "UTF-8")
        val o = get("https://de.openfoodfacts.org/cgi/search.pl?search_terms=$enc&search_simple=1&action=process&json=1&page_size=25&fields=$FIELDS")
        val a = o.optJSONArray("products") ?: JSONArray()
        (0 until a.length()).mapNotNull { parse(a.getJSONObject(it)) }
    } catch (_: Exception) { emptyList() }
}
