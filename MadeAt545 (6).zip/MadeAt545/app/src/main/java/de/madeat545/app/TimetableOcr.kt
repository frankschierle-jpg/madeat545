package de.madeat545.app

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.time.DayOfWeek
import java.time.LocalTime
import kotlin.math.abs

/**
 * Liest einen fotografierten Stundenplan aus (Texterkennung direkt auf dem Handy, ohne Internet).
 * Ergebnis: vermutetes Schulende je Wochentag + alle gefundenen Uhrzeiten.
 * Die App zeigt alles zur Kontrolle an – du bestätigst oder korrigierst.
 */
object TimetableOcr {

    data class Result(
        val endTimes: Map<DayOfWeek, LocalTime>,
        val allTimes: List<LocalTime>,
        val rawText: String,
    )

    private val dayWords = mapOf(
        DayOfWeek.MONDAY to listOf("montag", "mo"),
        DayOfWeek.TUESDAY to listOf("dienstag", "di"),
        DayOfWeek.WEDNESDAY to listOf("mittwoch", "mi"),
        DayOfWeek.THURSDAY to listOf("donnerstag", "do"),
        DayOfWeek.FRIDAY to listOf("freitag", "fr"),
    )

    private val timeRegex = Regex("""\b([01]?\d|2[0-3])[:.]([0-5]\d)\b""")

    fun parseTimes(s: String): List<LocalTime> =
        timeRegex.findAll(s).mapNotNull { m ->
            runCatching { LocalTime.of(m.groupValues[1].toInt(), m.groupValues[2].toInt()) }.getOrNull()
        }.filter { it.hour in 6..19 }.toList()

    private fun dayOf(text: String): DayOfWeek? {
        val w = text.lowercase().trim().trimEnd('.', ':')
        return dayWords.entries.firstOrNull { (_, words) -> words.any { w == it || w.startsWith(it) && it.length > 2 } }?.key
    }

    fun recognize(ctx: Context, uri: Uri, onDone: (Result?) -> Unit) {
        val image = try {
            loadScaled(uri.path ?: "")
        } catch (_: Throwable) {
            null
        }
        if (image == null) {
            onDone(null); return
        }
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            .process(image)
            .addOnSuccessListener { text -> onDone(analyze(text)) }
            .addOnFailureListener { onDone(null) }
    }

    /** Foto verkleinert laden (große Handyfotos sprengen sonst den Speicher) und richtig drehen. */
    private fun loadScaled(path: String): InputImage? {
        val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
        android.graphics.BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = android.graphics.BitmapFactory.decodeFile(path, opts) ?: return null
        val rotation = when (android.media.ExifInterface(path).getAttributeInt(
            android.media.ExifInterface.TAG_ORIENTATION, android.media.ExifInterface.ORIENTATION_NORMAL,
        )) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> 90
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> 180
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> 270
            else -> 0
        }
        return InputImage.fromBitmap(bmp, rotation)
    }

    private data class Box(val text: String, val cx: Float, val cy: Float, val top: Float, val bottom: Float)

    private fun analyze(text: Text): Result {
        val boxes = mutableListOf<Box>()
        text.textBlocks.forEach { b ->
            b.lines.forEach { l ->
                val r = l.boundingBox ?: return@forEach
                boxes += Box(l.text, r.exactCenterX(), r.exactCenterY(), r.top.toFloat(), r.bottom.toFloat())
            }
        }
        val allTimes = parseTimes(text.text).distinct().sorted()
        val ends = mutableMapOf<DayOfWeek, LocalTime>()

        // 1) Zeilen wie "Montag 8:00 - 14:00" → späteste Uhrzeit in der Zeile
        boxes.forEach { b ->
            val first = b.text.split(" ", "\t").firstOrNull() ?: return@forEach
            val d = dayOf(first) ?: return@forEach
            parseTimes(b.text).maxOrNull()?.let { ends[d] = it }
        }

        // 2) Tabelle: Wochentage als Spaltenköpfe, Uhrzeiten in der linken Spalte
        if (ends.size < 3) {
            val headers = boxes.mapNotNull { b -> dayOf(b.text)?.let { it to b } }.toMap()
            val timeRows = boxes.filter { parseTimes(it.text).isNotEmpty() }
            if (headers.size >= 3 && timeRows.isNotEmpty()) {
                val colWidth = headers.values.map { it.cx }.sorted().zipWithNext { a, c -> c - a }.minOrNull() ?: 200f
                headers.forEach { (day, h) ->
                    val cells = boxes.filter { c ->
                        c !== h && c.top > h.bottom && abs(c.cx - h.cx) < colWidth / 2 &&
                            parseTimes(c.text).isEmpty() && dayOf(c.text) == null && c.text.isNotBlank()
                    }
                    val last = cells.maxByOrNull { it.cy } ?: return@forEach
                    val row = timeRows.minByOrNull { abs(it.cy - last.cy) } ?: return@forEach
                    parseTimes(row.text).maxOrNull()?.let { ends[day] = it }
                }
            }
        }
        return Result(ends, allTimes, text.text)
    }
}
