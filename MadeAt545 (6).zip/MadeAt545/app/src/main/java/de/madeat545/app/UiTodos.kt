package de.madeat545.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val dateFmt = DateTimeFormatter.ofPattern("EEE, d. MMM", Locale.GERMAN)

fun todoSubtitle(t: Todo, today: LocalDate): String = buildList {
    add(if (t.isEvent) "Termin" else "To-Do")
    val d = t.date
    if (d != null) add(
        when {
            d == today -> "heute"
            d == today.plusDays(1) -> "morgen"
            d.isBefore(today) -> "überfällig (${d.format(dateFmt)})"
            else -> d.format(dateFmt)
        }
    )
    t.time?.let { add("$it Uhr") }
    if (t.remindMin >= 0) add("🔔 " + Reminders.label(t.remindMin))
    if (t.repeat != Repeat.NONE) add(t.repeat.label)
}.joinToString(" · ")

@Composable
fun TodoRow(t: Todo, today: LocalDate, onCheck: () -> Unit, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .background(if (t.done) C.Beige.copy(alpha = 0.55f) else C.Beige)
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.clip(CircleShape).clickable { onCheck() }) { CheckCircle(t.done) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                t.title, color = if (t.done) C.MokkaLight else C.Mokka, fontSize = 16.sp,
                fontWeight = if (t.isEvent || t.priority == 2) FontWeight.Medium else FontWeight.Normal,
                textDecoration = if (t.done) TextDecoration.LineThrough else null,
            )
            Text(todoSubtitle(t, today), color = C.MokkaLight, fontSize = 13.sp)
            if (t.note.isNotBlank()) Text(t.note, color = C.MokkaLight, fontSize = 13.sp)
        }
        if (!t.isEvent) {
            Box(
                Modifier
                    .size(10.dp)
                    .clip(CircleShape)
                    .background(
                        when (t.priority) {
                            2 -> C.Mokka
                            1 -> C.Sand
                            else -> C.Line
                        }
                    )
            )
        }
    }
}

@Composable
fun TodosScreen(host: MainActivity) {
    val store = host.store
    val today = LocalDate.now()
    val all = store.todos()
    var editing by remember { mutableStateOf<Todo?>(null) }
    var showDone by remember { mutableStateOf(false) }

    val open = all.filter { !it.done }
    val timeOrder = compareBy<Todo>({ it.date }, { it.time ?: LocalTime.MAX })
    val overdue = open.filter { it.date != null && it.date.isBefore(today) }.sortedWith(timeOrder)
    val todayList = open.filter { it.date == today }.sortedWith(timeOrder)
    val upcoming = open.filter { it.date != null && it.date.isAfter(today) }.sortedWith(timeOrder)
    val noDate = open.filter { it.date == null }.sortedByDescending { it.priority }
    val doneList = all.filter { it.done }.sortedByDescending { it.id }.take(15)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Title("To-Dos & Termine") }
            ActionChip("+ Neu") { editing = Todo(id = System.currentTimeMillis(), title = "") }
        }
        Spacer(Modifier.height(14.dp))

        if (open.isEmpty()) {
            MCard {
                Label("Alles erledigt")
                Hint("Tippe auf „+ Neu“, um ein To-Do oder einen wichtigen Termin mit Erinnerung anzulegen.")
            }
        }

        TodoSection("Überfällig", overdue, today, host) { editing = it }
        TodoSection("Heute", todayList, today, host) { editing = it }
        TodoSection("Demnächst", upcoming, today, host) { editing = it }
        TodoSection("Ohne Datum", noDate, today, host) { editing = it }

        if (doneList.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Text(
                if (showDone) "Erledigte ausblenden" else "Erledigte anzeigen (${doneList.size})",
                color = C.MokkaLight, fontSize = 14.sp,
                modifier = Modifier.clickable { showDone = !showDone }.padding(vertical = 6.dp),
            )
            if (showDone) TodoSection("Erledigt", doneList, today, host) { editing = it }
        }
        Spacer(Modifier.height(12.dp))
    }

    editing?.let { t ->
        TodoEditor(
            host = host,
            initial = t,
            isNew = all.none { it.id == t.id },
            onDismiss = { editing = null },
            onSave = { host.saveTodo(it); editing = null },
            onDelete = { host.deleteTodo(it); editing = null },
        )
    }
}

@Composable
fun TodoSection(title: String, list: List<Todo>, today: LocalDate, host: MainActivity, onEdit: (Todo) -> Unit) {
    if (list.isEmpty()) return
    Spacer(Modifier.height(6.dp))
    Label(title)
    Spacer(Modifier.height(8.dp))
    list.forEach { t ->
        TodoRow(t, today, onCheck = { host.completeTodo(t, !t.done) }, onClick = { onEdit(t) })
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun TodoEditor(
    host: MainActivity,
    initial: Todo,
    isNew: Boolean,
    onDismiss: () -> Unit,
    onSave: (Todo) -> Unit,
    onDelete: (Todo) -> Unit,
) {
    var t by remember(initial.id) { mutableStateOf(initial) }
    var error by remember { mutableStateOf("") }
    val today = LocalDate.now()

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = C.Creme,
        title = { Text(if (isNew) "Neu" else "Bearbeiten", color = C.Mokka) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Choice(listOf(false to "To-Do", true to "Termin"), t.isEvent) { v -> t = t.copy(isEvent = v) }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = t.title, onValueChange = { t = t.copy(title = it); error = "" },
                    label = { Text("Titel") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = t.note, onValueChange = { t = t.copy(note = it) },
                    label = { Text("Notiz (optional)") }, modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(12.dp))

                Label("Datum")
                Spacer(Modifier.height(6.dp))
                val dateKey = when (t.date) {
                    null -> "none"
                    today -> "today"
                    today.plusDays(1) -> "tomorrow"
                    else -> "other"
                }
                Choice(
                    listOf(
                        "none" to "Kein Datum", "today" to "Heute", "tomorrow" to "Morgen",
                        "other" to (if (dateKey == "other") t.date?.format(dateFmt) ?: "Datum wählen" else "Datum wählen …"),
                    ),
                    dateKey,
                ) { key ->
                    when (key) {
                        "none" -> { t = t.copy(date = null, remindMin = -1) }
                        "today" -> { t = t.copy(date = today) }
                        "tomorrow" -> { t = t.copy(date = today.plusDays(1)) }
                        else -> { host.pickDate(t.date) { d -> t = t.copy(date = d) } }
                    }
                }
                Spacer(Modifier.height(12.dp))

                Label("Uhrzeit")
                Spacer(Modifier.height(6.dp))
                Choice(
                    listOf(false to "Keine", true to (t.time?.let { "$it Uhr" } ?: "Uhrzeit wählen …")),
                    t.time != null,
                ) { on ->
                    if (on) {
                        host.pickTime(t.time) { tm -> t = t.copy(time = tm) }
                    } else {
                        t = t.copy(time = null)
                    }
                }
                Spacer(Modifier.height(12.dp))

                Label("Erinnerung")
                Hint(if (t.date == null) "Wähle zuerst ein Datum." else if (t.time == null) "Ohne Uhrzeit erinnert die App um 9:00 Uhr." else "Kommt als Benachrichtigung aufs Handy.")
                Spacer(Modifier.height(6.dp))
                Choice(Reminders.options, t.remindMin) { m ->
                    if (t.date != null || m == -1) {
                        t = t.copy(remindMin = m)
                    }
                }
                Spacer(Modifier.height(12.dp))

                Label("Wiederholen")
                Spacer(Modifier.height(6.dp))
                Choice(Repeat.values().map { it to it.label }, t.repeat) { r -> t = t.copy(repeat = r) }

                if (!t.isEvent) {
                    Spacer(Modifier.height(12.dp))
                    Label("Priorität")
                    Spacer(Modifier.height(6.dp))
                    Choice(listOf(2 to "Hoch", 1 to "Mittel", 0 to "Niedrig"), t.priority) { p -> t = t.copy(priority = p) }
                }
                if (error.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    Text(error, color = C.Mokka, fontWeight = FontWeight.Medium)
                }
                if (!isNew) {
                    Spacer(Modifier.height(16.dp))
                    Text(
                        "Löschen", color = C.Mokka, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(C.Rose)
                            .clickable { onDelete(t) }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                when {
                    t.title.isBlank() -> error = "Bitte gib einen Titel ein."
                    t.isEvent && t.date == null -> error = "Ein Termin braucht ein Datum."
                    else -> onSave(t.copy(title = t.title.trim()))
                }
            }) { Text("Speichern", color = C.Mokka, fontWeight = FontWeight.Medium) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen", color = C.MokkaLight) } },
    )
}
