package de.madeat545.app

import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.LocalTime

enum class Repeat(val label: String) { NONE("Nie"), DAILY("Täglich"), WEEKLY("Wöchentlich"), MONTHLY("Monatlich") }

/** To-Do oder Termin. */
data class Todo(
    val id: Long,
    val title: String,
    val note: String = "",
    val isEvent: Boolean = false,
    val date: LocalDate? = null,
    val time: LocalTime? = null,
    val remindMin: Int = -1, // -1 = keine Erinnerung, 0 = zur Zeit, sonst Minuten vorher
    val repeat: Repeat = Repeat.NONE,
    val priority: Int = 1, // 0 niedrig, 1 mittel, 2 hoch
    val done: Boolean = false,
) {
    /** Zeitpunkt, an dem die Erinnerung kommt (oder null). */
    fun reminderAt(): LocalDateTime? {
        if (remindMin < 0 || date == null || done) return null
        val at = date.atTime(time ?: LocalTime.of(9, 0))
        return at.minusMinutes(remindMin.toLong())
    }

    fun nextOccurrence(): LocalDate? = when (repeat) {
        Repeat.NONE -> null
        Repeat.DAILY -> date?.plusDays(1)
        Repeat.WEEKLY -> date?.plusWeeks(1)
        Repeat.MONTHLY -> date?.plusMonths(1)
    }

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("title", title)
        put("note", note)
        put("isEvent", isEvent)
        put("date", date?.toString() ?: "")
        put("time", time?.toString() ?: "")
        put("remindMin", remindMin)
        put("repeat", repeat.name)
        put("priority", priority)
        put("done", done)
    }

    companion object {
        fun fromJson(o: JSONObject): Todo = Todo(
            id = o.getLong("id"),
            title = o.optString("title"),
            note = o.optString("note"),
            isEvent = o.optBoolean("isEvent"),
            date = o.optString("date").takeIf { it.isNotEmpty() }?.let { LocalDate.parse(it) },
            time = o.optString("time").takeIf { it.isNotEmpty() }?.let { LocalTime.parse(it) },
            remindMin = o.optInt("remindMin", -1),
            repeat = runCatching { Repeat.valueOf(o.optString("repeat")) }.getOrDefault(Repeat.NONE),
            priority = o.optInt("priority", 1),
            done = o.optBoolean("done"),
        )

        fun listToJson(list: List<Todo>): String = JSONArray().apply { list.forEach { put(it.toJson()) } }.toString()

        fun listFromJson(s: String?): List<Todo> {
            if (s.isNullOrEmpty()) return emptyList()
            return try {
                val a = JSONArray(s)
                (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
            } catch (_: Exception) {
                emptyList()
            }
        }
    }
}

object Reminders {
    val options = listOf(-1 to "Keine", 0 to "Zur Zeit", 15 to "15 Min. vorher", 60 to "1 Std. vorher", 24 * 60 to "1 Tag vorher")
    fun label(min: Int) = options.firstOrNull { it.first == min }?.second ?: "$min Min. vorher"
}

object TimetableJson {
    private fun mapToJson(m: Map<java.time.DayOfWeek, LocalTime>) = JSONObject().apply {
        m.forEach { (k, v) -> put(k.name, v.toString()) }
    }
    private fun mapFromJson(o: JSONObject): Map<java.time.DayOfWeek, LocalTime> {
        val r = mutableMapOf<java.time.DayOfWeek, LocalTime>()
        o.keys().forEach { k -> runCatching { r[java.time.DayOfWeek.valueOf(k)] = LocalTime.parse(o.getString(k)) } }
        return r
    }

    fun toJson(list: List<Timetable>): String = JSONArray().apply {
        list.forEach { t ->
            put(JSONObject().apply {
                put("validFrom", t.validFrom.toString())
                put("endA", mapToJson(t.endA))
                put("endB", mapToJson(t.endB))
                put("travelMin", t.travelMin)
            })
        }
    }.toString()

    fun fromJson(s: String?): List<Timetable> {
        if (s.isNullOrEmpty()) return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Timetable(
                    LocalDate.parse(o.getString("validFrom")),
                    mapFromJson(o.getJSONObject("endA")),
                    mapFromJson(o.getJSONObject("endB")),
                    o.optInt("travelMin", 25),
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
