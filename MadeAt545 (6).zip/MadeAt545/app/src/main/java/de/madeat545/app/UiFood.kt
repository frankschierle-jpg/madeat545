package de.madeat545.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.LocalTime
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

private fun Double.r(): String = roundToInt().toString()
private fun Double.g(): String = if (this < 10) "%.1f".format(this).replace('.', ',') else roundToInt().toString()

fun defaultMeal(): Meal {
    val h = LocalTime.now().hour
    return when {
        h < 10 -> Meal.BREAKFAST
        h < 15 -> Meal.LUNCH
        h < 17 -> Meal.SNACK
        else -> Meal.DINNER
    }
}

@Composable
fun FoodScreen(host: MainActivity) {
    val store = host.store
    val today = LocalDate.now()
    val entries = store.food(today)
    val kcal = entries.sumOf { it.kcal }
    val p = entries.sumOf { it.protein }
    val c = entries.sumOf { it.carbs }
    val f = entries.sumOf { it.fat }
    val sugar = entries.sumOf { it.sugar }
    val fiber = entries.sumOf { it.fiber }
    val water = store.water(today)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Title("Essen heute")
        Hint("Iss dich satt – an Trainingstagen braucht dein Körper extra Energie.")
        Spacer(Modifier.height(14.dp))

        MCard {
            Row(verticalAlignment = Alignment.Bottom) {
                Text(kcal.r(), fontFamily = FontFamily.Serif, fontSize = 34.sp, color = C.Mokka)
                Spacer(Modifier.width(6.dp))
                Text("kcal", color = C.MokkaLight, fontSize = 15.sp, modifier = Modifier.padding(bottom = 6.dp))
            }
            Spacer(Modifier.height(10.dp))
            MacroBar(p, c, f)
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                MacroLabel(C.Mokka, "Eiweiß", p)
                MacroLabel(C.Sand, "Kohlenhydrate", c)
                MacroLabel(C.Rose, "Fett", f)
            }
            Spacer(Modifier.height(6.dp))
            Hint("davon Zucker ${sugar.g()} g · Ballaststoffe ${fiber.g()} g")
            if (entries.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Hint(balanceTip(p, c, f))
            }
        }
        Spacer(Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) { ActionChip("Barcode scannen") { host.scanBarcode() } }
            Box(Modifier.weight(1f)) { ActionChip("Suchen", color = C.Rose) { host.foodSearchOpen.value = true } }
        }
        if (host.foodMessage.value.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(host.foodMessage.value, color = C.Mokka, fontSize = 14.sp)
        }
        Spacer(Modifier.height(14.dp))

        Meal.values().forEach { meal ->
            val list = entries.filter { it.meal == meal }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Label(meal.label) }
                if (list.isNotEmpty()) Hint("${list.sumOf { it.kcal }.r()} kcal")
            }
            Spacer(Modifier.height(6.dp))
            if (list.isEmpty()) {
                Hint("Noch nichts eingetragen")
            }
            list.forEach { e ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(C.Beige)
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(e.food.name, color = C.Mokka, fontSize = 15.sp)
                        Hint("${e.grams.r()} g · ${e.kcal.r()} kcal · E ${e.protein.g()} g · KH ${e.carbs.g()} g · F ${e.fat.g()} g" + if (e.photo != null) " · 📷" else "")
                    }
                    Text(
                        "✕", color = C.MokkaLight, fontSize = 16.sp,
                        modifier = Modifier.clip(CircleShape).clickable { store.deleteFood(e) }.padding(8.dp),
                    )
                }
                Spacer(Modifier.height(6.dp))
            }
            Spacer(Modifier.height(10.dp))
        }

        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) { Label("Wasser") }
                Hint("$water von 8 Gläsern")
            }
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                (1..8).forEach { i ->
                    Box(
                        Modifier
                            .weight(1f)
                            .height(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (i <= water) C.Sand else C.Creme)
                            .border(1.dp, C.Line, RoundedCornerShape(10.dp))
                            .clickable { store.setWater(today, if (i == water) i - 1 else i) },
                    )
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Idee fürs Mittagessen")
            val r = Recipes.forDay(store, today)
            Text(r.name, fontFamily = FontFamily.Serif, color = C.Mokka, fontSize = 16.sp)
            Hint("${r.minutes} Min. · " + r.ingredients.joinToString(", "))
            Spacer(Modifier.height(8.dp))
            ActionChip("Anderer Vorschlag", color = C.Creme) { host.nextRecipe(today) }
        }
        Spacer(Modifier.height(16.dp))
    }

    if (host.foodSearchOpen.value) FoodSearchDialog(host)
    host.foodPick.value?.let { food -> FoodAmountDialog(host, food) }
}

private fun balanceTip(p: Double, c: Double, f: Double): String {
    val total = p * 4 + c * 4 + f * 9
    if (total <= 0) return ""
    val pp = p * 4 / total
    val fp = f * 9 / total
    return when {
        fp > 0.40 -> "Heute ist viel Fett dabei – Gemüse, Obst oder Vollkorn gleichen das gut aus."
        pp < 0.12 -> "Etwas mehr Eiweiß (Quark, Eier, Joghurt, Hähnchen, Linsen) hilft deinen Muskeln beim Sport."
        else -> "Gute Mischung aus Eiweiß, Kohlenhydraten und Fett."
    }
}

@Composable
private fun MacroLabel(color: Color, name: String, grams: Double) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(5.dp))
        Text("$name ${grams.g()} g", color = C.Mokka, fontSize = 13.sp)
    }
}

@Composable
private fun MacroBar(p: Double, c: Double, f: Double) {
    val pe = p * 4
    val ce = c * 4
    val fe = f * 9
    val total = pe + ce + fe
    Row(
        Modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(C.Creme)
    ) {
        if (total > 0) {
            if (pe > 0) Box(Modifier.weight(pe.toFloat()).fillMaxHeight().background(C.Mokka))
            if (ce > 0) Box(Modifier.weight(ce.toFloat()).fillMaxHeight().background(C.Sand))
            if (fe > 0) Box(Modifier.weight(fe.toFloat()).fillMaxHeight().background(C.Rose))
        }
    }
}

@Composable
private fun FoodSearchDialog(host: MainActivity) {
    var q by remember { mutableStateOf("") }
    val results = host.foodResults.value
    val recent = host.store.recentFoods()

    AlertDialog(
        onDismissRequest = { host.foodSearchOpen.value = false },
        containerColor = C.Creme,
        title = { Text("Lebensmittel suchen", color = C.Mokka) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = q,
                    onValueChange = { q = it; host.searchFoodLocal(it) },
                    label = { Text("z. B. Apfel, Skyr, Haferflocken") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                ActionChip("Online suchen") { host.searchFoodOnline(q) }
                if (host.foodMessage.value.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Hint(host.foodMessage.value)
                }
                Spacer(Modifier.height(10.dp))
                val shown = if (q.isBlank()) recent else results
                if (q.isBlank() && recent.isNotEmpty()) Hint("Zuletzt benutzt")
                shown.forEach { food ->
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                host.foodSearchOpen.value = false
                                host.foodPick.value = food
                            }
                            .padding(vertical = 8.dp, horizontal = 4.dp)
                    ) {
                        Text(food.name, color = C.Mokka, fontSize = 15.sp)
                        Hint("100 g: ${food.kcal.r()} kcal · E ${food.protein.g()} · KH ${food.carbs.g()} · F ${food.fat.g()}" + if (food.source.isNotEmpty()) " · ${food.source}" else "")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { host.foodSearchOpen.value = false }) { Text("Schließen", color = C.Mokka) }
        },
    )
}

@Composable
private fun FoodAmountDialog(host: MainActivity, food: Food) {
    var gramsText by remember(food) { mutableStateOf(food.servingGrams.r()) }
    var meal by remember(food) { mutableStateOf(defaultMeal()) }
    val grams = gramsText.replace(',', '.').toDoubleOrNull() ?: 0.0
    val k = food.kcal * grams / 100

    AlertDialog(
        onDismissRequest = { host.cancelFood() },
        containerColor = C.Creme,
        title = { Text(food.name, color = C.Mokka) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Hint("Pro 100 g: ${food.kcal.r()} kcal · Eiweiß ${food.protein.g()} g · Kohlenhydrate ${food.carbs.g()} g · Fett ${food.fat.g()} g")
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(
                    value = gramsText,
                    onValueChange = { gramsText = it.filter { ch -> ch.isDigit() || ch == ',' || ch == '.' } },
                    label = { Text("Menge in Gramm") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                )
                Spacer(Modifier.height(8.dp))
                Choice(
                    listOf(food.servingGrams, 50.0, 100.0, 150.0, 200.0).distinct().map { it to "${it.r()} g" },
                    grams,
                ) { gramsText = it.r() }
                Spacer(Modifier.height(10.dp))
                Text(
                    "= ${k.r()} kcal · E ${(food.protein * grams / 100).g()} g · KH ${(food.carbs * grams / 100).g()} g · F ${(food.fat * grams / 100).g()} g",
                    color = C.Mokka, fontWeight = FontWeight.Medium, fontSize = 14.sp,
                )
                Spacer(Modifier.height(12.dp))
                Label("Mahlzeit")
                Spacer(Modifier.height(6.dp))
                Choice(Meal.values().map { it to it.label }, meal) { meal = it }
                Spacer(Modifier.height(12.dp))
                ActionChip(if (host.foodPhoto.value != null) "Foto gespeichert ✓" else "Foto vom Essen (optional)", color = C.Beige) {
                    host.takeFoodPhoto()
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (grams > 0) host.addFood(food, grams, meal) }) {
                Text("Hinzufügen", color = C.Mokka, fontWeight = FontWeight.Medium)
            }
        },
        dismissButton = { TextButton(onClick = { host.cancelFood() }) { Text("Abbrechen", color = C.MokkaLight) } },
    )
}

/** Startseite: nach links/rechts wischen zwischen „Heute“ und „Essen“. */
@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun TodayPager(host: MainActivity) {
    val pager = androidx.compose.foundation.pager.rememberPagerState(pageCount = { 2 })
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            listOf("Heute", "Essen").forEachIndexed { i, label ->
                val on = pager.currentPage == i
                Text(
                    label,
                    color = C.Mokka, fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.Medium else FontWeight.Normal,
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (on) C.Sand else C.Beige)
                        .clickable { scope.launch { pager.animateScrollToPage(i) } }
                        .padding(horizontal = 14.dp, vertical = 5.dp),
                )
            }
        }
        androidx.compose.foundation.pager.HorizontalPager(state = pager, modifier = Modifier.fillMaxSize()) { page ->
            if (page == 0) TodayScreen(host) else FoodScreen(host)
        }
    }
}
