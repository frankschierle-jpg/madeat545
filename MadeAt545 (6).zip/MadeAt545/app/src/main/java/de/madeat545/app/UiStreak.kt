package de.madeat545.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun StreakScreen(host: MainActivity) {
    val store = host.store
    val today = LocalDate.now()
    val streak = store.streak(today)
    val best = store.longestStreak(today)
    var month by remember { mutableStateOf(YearMonth.now()) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Title("Dein Streak")
        Spacer(Modifier.height(16.dp))

        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                val next = listOf(7, 14, 30, 50, 100, 200).firstOrNull { it > streak } ?: (streak + 1)
                StreakRing(progress = streak.toFloat() / next, size = 120, label = "$streak", sub = if (streak == 1) "Tag" else "Tage")
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Label("Rekord: $best ${if (best == 1) "Tag" else "Tage"}")
                    Spacer(Modifier.height(4.dp))
                    Hint("Noch ${next - streak} bis zum nächsten Abzeichen ($next Tage).")
                    Spacer(Modifier.height(4.dp))
                    Hint("Wochenenden und Ferien pausieren den Streak.")
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Abzeichen")
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(7, 14, 30, 50, 100).forEach { n ->
                    val earned = best >= n
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(if (earned) C.Sand else C.Creme)
                                .border(2.dp, if (earned) C.Sand else C.Line, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("$n", fontFamily = FontFamily.Serif, color = if (earned) C.Mokka else C.MokkaLight, fontSize = 16.sp)
                        }
                        Text("Tage", fontSize = 11.sp, color = C.MokkaLight)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Einzel-Streaks")
            Spacer(Modifier.height(8.dp))
            listOf(
                "bett" to "Bett gemacht",
                "morgensport" to "Morgensport",
                "mittag" to "Mittagessen",
                "abendsport" to "Abendsport",
            ).forEach { (id, label) ->
                val n = store.itemStreak(today, id)
                Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(label, color = C.Mokka, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    Pill("$n ${if (n == 1) "Tag" else "Tage"}", if (n > 0) C.Sand else C.Creme)
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("‹", fontSize = 26.sp, color = C.Mokka, modifier = Modifier.clickable { month = month.minusMonths(1) }.padding(horizontal = 12.dp))
                Text(
                    month.format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale.GERMAN)),
                    fontFamily = FontFamily.Serif, fontSize = 18.sp, color = C.Mokka,
                    modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                )
                Text("›", fontSize = 26.sp, color = C.Mokka, modifier = Modifier.clickable { month = month.plusMonths(1) }.padding(horizontal = 12.dp))
            }
            Spacer(Modifier.height(8.dp))
            MonthGrid(store, month, today)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Legend(C.Sand, "geschafft")
                Legend(C.Rose, "verpasst")
                Legend(C.Creme, "frei")
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(12.dp).clip(CircleShape).background(color).border(1.dp, C.Line, CircleShape))
        Spacer(Modifier.width(4.dp))
        Text(text, fontSize = 12.sp, color = C.MokkaLight)
    }
}

@Composable
private fun MonthGrid(store: Store, month: YearMonth, today: LocalDate) {
    val first = month.atDay(1)
    val offset = first.dayOfWeek.value - 1 // Montag = 0
    val days = month.lengthOfMonth()
    val start = store.startDate
    Row(Modifier.fillMaxWidth()) {
        listOf("Mo", "Di", "Mi", "Do", "Fr", "Sa", "So").forEach {
            Text(it, fontSize = 12.sp, color = C.MokkaLight, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        }
    }
    Spacer(Modifier.height(4.dp))
    val cells = offset + days
    val rows = (cells + 6) / 7
    for (r in 0 until rows) {
        Row(Modifier.fillMaxWidth()) {
            for (c in 0 until 7) {
                val idx = r * 7 + c - offset + 1
                Box(Modifier.weight(1f).aspectRatio(1f).padding(3.dp), contentAlignment = Alignment.Center) {
                    if (idx in 1..days) {
                        val d = month.atDay(idx)
                        val bg = when {
                            d.isAfter(today) || d.isBefore(start) -> Color.Transparent
                            !Schedule.isSchoolDay(d) -> C.Creme
                            store.isComplete(d) -> C.Sand
                            d == today -> Color.Transparent
                            else -> C.Rose
                        }
                        Box(
                            Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                                .background(bg)
                                .border(if (d == today) 2.dp else 0.dp, if (d == today) C.Sand else Color.Transparent, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text("$idx", fontSize = 13.sp, color = C.Mokka, fontWeight = if (d == today) FontWeight.Medium else FontWeight.Normal)
                        }
                    }
                }
            }
        }
    }
}
