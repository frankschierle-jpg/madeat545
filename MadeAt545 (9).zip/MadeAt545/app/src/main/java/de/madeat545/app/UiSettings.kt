package de.madeat545.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.DayOfWeek
import java.time.LocalDate
import java.time.format.DateTimeFormatter

private val dayNames = listOf(
    DayOfWeek.MONDAY to "Montag", DayOfWeek.TUESDAY to "Dienstag", DayOfWeek.WEDNESDAY to "Mittwoch",
    DayOfWeek.THURSDAY to "Donnerstag", DayOfWeek.FRIDAY to "Freitag",
)
private val dmy = DateTimeFormatter.ofPattern("dd.MM.yyyy")

@Composable
fun SettingsScreen(host: MainActivity) {
    val store = host.store
    val today = LocalDate.now()
    val week = Schedule.weekType(today, store.weekOffset)
    val tt = store.timetableFor(today)
    val future = store.timetables().filter { it.validFrom.isAfter(today) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Title("Einstellungen")
        Spacer(Modifier.height(16.dp))

        MCard {
            Label("Stundenplan")
            Hint("Gilt seit ${tt.validFrom.format(dmy)} · Heimweg ca. ${tt.travelMin} Min.")
            Spacer(Modifier.height(8.dp))
            dayNames.forEach { (d, name) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(name, color = C.Mokka, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text("A: bis ${tt.endA[d] ?: "–"}   B: bis ${tt.endB[d] ?: "–"}", color = C.MokkaLight, fontSize = 14.sp)
                }
            }
            future.forEach { f ->
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Hint("Neuer Plan ab ${f.validFrom.format(dmy)} ist gespeichert.")
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "verwerfen", color = C.Mokka, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(C.Rose)
                            .clickable { store.deleteTimetable(f.validFrom) }.padding(horizontal = 10.dp, vertical = 4.dp),
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            ActionChip("Stundenplan ändern / fotografieren") { host.openTimetableEditor() }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Wecker")
            Text("Nächster: " + AlarmScheduler.nextWakeText(host), color = C.MokkaLight, fontSize = 14.sp)
            Hint("Nur an Schultagen · nicht am Wochenende und in den Ferien")
            Spacer(Modifier.height(12.dp))

            // Nur für den nächsten Schultag (z. B. erste Stunde frei)
            var next = today.plusDays(if (java.time.LocalTime.now().isAfter(store.wakeTimeFor(today))) 1 else 0)
            while (!Schedule.isSchoolDay(next)) next = next.plusDays(1)
            val nextName = if (next == today) "heute" else if (next == today.plusDays(1)) "morgen" else next.format(java.time.format.DateTimeFormatter.ofPattern("EEEE", java.util.Locale.GERMAN))
            val once = store.wakeOverride(next)
            Text("Nur $nextName anders?", color = C.Mokka, fontSize = 15.sp)
            Hint("Zum Beispiel, wenn die erste Stunde ausfällt.")
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                ActionChip(if (once != null) "$nextName um $once" else "Zeit für $nextName wählen", color = if (once != null) C.Sand else C.Creme) {
                    host.pickTime(once ?: store.wakeTimeFor(next)) { t -> host.setWakeOnce(next, t) }
                }
                if (once != null) {
                    Spacer(Modifier.width(8.dp))
                    ActionChip("zurücksetzen", color = C.Rose) { host.setWakeOnce(next, null) }
                }
            }
            Spacer(Modifier.height(14.dp))

            Text("Standard-Weckzeit", color = C.Mokka, fontSize = 15.sp)
            Spacer(Modifier.height(6.dp))
            ActionChip(store.wakeDefault.toString(), color = C.Creme) {
                host.pickTime(store.wakeDefault) { t -> host.setWakeDefault(t) }
            }
            Spacer(Modifier.height(14.dp))

            Text("Feste Weckzeit pro Wochentag", color = C.Mokka, fontSize = 15.sp)
            Hint("Leer = Standard. Antippen zum Ändern.")
            Spacer(Modifier.height(6.dp))
            dayNames.forEach { (d, name) ->
                val own = store.wakeForDay(d)
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = C.Mokka, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    ActionChip(own?.toString() ?: "Standard (${store.wakeDefault})", color = if (own != null) C.Sand else C.Creme) {
                        host.pickTime(own ?: store.wakeDefault) { t -> host.setWakeDay(d, t) }
                    }
                    if (own != null) {
                        Spacer(Modifier.width(6.dp))
                        Text("✕", color = C.MokkaLight, fontSize = 16.sp, modifier = Modifier.clickable { host.setWakeDay(d, null) }.padding(6.dp))
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            ActionChip("Test-Wecker in 1 Minute") { host.testAlarm() }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Damit der Wecker sicher klingelt")
            Hint("Alles sollte auf „OK“ stehen. Tippe sonst auf den Punkt.")
            Spacer(Modifier.height(8.dp))
            PermissionRow("Benachrichtigungen", host.hasNotificationPermission()) { host.requestNotifications() }
            PermissionRow("Vollbild-Wecker", host.canFullScreen()) { host.requestFullScreen() }
            PermissionRow("Genaue Weckzeit", AlarmScheduler.canExact(host)) { host.requestExact() }
            PermissionRow("Akku-Optimierung aus", host.ignoresBattery()) { host.requestBattery() }
            Spacer(Modifier.height(6.dp))
            Hint("Samsung-Tipp: Einstellungen → Akku → Hintergrundnutzungslimits → „Made at 5:45“ zu „Nie im Standby“ hinzufügen.")
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Schulwoche")
            Text("Diese Woche ist eine $week-Woche.", color = C.MokkaLight, fontSize = 14.sp)
            Hint("Ferienwochen zählen nicht mit – nach den Ferien geht es mit der nächsten Woche weiter.")
            Spacer(Modifier.height(10.dp))
            ActionChip("Stimmt nicht – A/B tauschen") { host.switchWeek() }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Freizeittermine")
            Schedule.activities.forEach { a ->
                Hint("${dayNames.firstOrNull { it.first == a.day }?.second}: ${a.title} ${a.start}–${a.end} · Weg ${a.travelMin} Min.")
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            val v = try {
                host.packageManager.getPackageInfo(host.packageName, 0).versionName
            } catch (_: Exception) { "?" }
            Label("App-Version $v")
            Hint("Enthält: einstellbare Weckzeit, Essen-Seite, To-Dos & Termine, Stundenplan, Streak-Statistik.")
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Sync mit Google-Konto")
            Hint("Kommt als nächster Schritt: Dafür braucht die App einmalig ein kostenloses Firebase-Projekt. Bis dahin werden alle Daten sicher auf diesem Handy gespeichert.")
        }
        Spacer(Modifier.height(12.dp))
    }
}

@Composable
private fun PermissionRow(label: String, ok: Boolean, onFix: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(enabled = !ok) { onFix() }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = C.Mokka, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Pill(if (ok) "OK" else "Einrichten", if (ok) C.Sand else C.Rose)
    }
}

/** Stundenplan bearbeiten: eintippen oder fotografieren, Vorschau, speichern. */
@Composable
fun TimetableScreen(host: MainActivity) {
    val draft = host.timetableDraft.value ?: return
    val week = host.draftWeek.value
    val ends = if (week == WeekType.A) draft.endA else draft.endB

    fun setEnd(d: DayOfWeek, t: java.time.LocalTime) {
        val cur = host.timetableDraft.value ?: return
        host.timetableDraft.value = if (week == WeekType.A) cur.copy(endA = cur.endA + (d to t)) else cur.copy(endB = cur.endB + (d to t))
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.weight(1f)) { Title("Stundenplan") }
            ActionChip("Abbrechen", color = C.Beige) { host.closeTimetableEditor() }
        }
        Spacer(Modifier.height(6.dp))
        Hint("Nur das Schulende pro Tag zählt. Morgenplan, Abendplan und Freizeittermine bleiben gleich – den Nachmittag plant die App automatisch neu.")
        Spacer(Modifier.height(14.dp))

        MCard {
            Label("Gilt ab")
            Spacer(Modifier.height(6.dp))
            ActionChip(draft.validFrom.format(dmy), color = C.Creme) {
                host.pickDate(draft.validFrom) { d -> host.timetableDraft.value = host.timetableDraft.value?.copy(validFrom = d) }
            }
            Spacer(Modifier.height(4.dp))
            Hint("Bis dahin bleibt der alte Plan aktiv – z. B. erster Schultag nach den Ferien.")
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Welche Woche bearbeitest du?")
            Spacer(Modifier.height(6.dp))
            Choice(listOf(WeekType.A to "A-Woche", WeekType.B to "B-Woche"), week) { host.draftWeek.value = it }
            Spacer(Modifier.height(12.dp))
            ActionChip("Stundenplan fotografieren ($week-Woche)", color = C.Rose) { host.photographTimetable() }
            if (host.ocrMessage.value.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Text(host.ocrMessage.value, color = C.Mokka, fontSize = 14.sp)
            }
            Spacer(Modifier.height(12.dp))
            Hint("Schulende antippen zum Ändern:")
            Spacer(Modifier.height(6.dp))
            dayNames.forEach { (d, name) ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(name, color = C.Mokka, fontSize = 15.sp, modifier = Modifier.weight(1f))
                    ActionChip("bis ${ends[d] ?: "–"}", color = C.Creme) {
                        host.pickTime(ends[d]) { t -> setEnd(d, t) }
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Heimweg nach der Schule")
            Spacer(Modifier.height(6.dp))
            Choice(listOf(15 to "15 Min.", 20 to "20 Min.", 25 to "25 Min.", 30 to "30 Min.", 40 to "40 Min."), draft.travelMin) { m ->
                host.timetableDraft.value = host.timetableDraft.value?.copy(travelMin = m)
            }
        }
        Spacer(Modifier.height(12.dp))

        MCard {
            Label("Vorschau $week-Woche")
            Spacer(Modifier.height(6.dp))
            dayNames.forEach { (d, name) ->
                val end = ends[d]
                if (end != null) {
                    val seq = Schedule.afternoon(end, draft.travelMin, d).filter { it.id != "schule" }
                    Text(name, color = C.Mokka, fontSize = 14.sp, fontFamily = FontFamily.Serif)
                    Hint(seq.joinToString(" → ") { it.title + (it.note?.takeIf { n -> n.startsWith("ca.") }?.let { n -> " ($n)" } ?: "") })
                    Spacer(Modifier.height(6.dp))
                }
            }
        }
        Spacer(Modifier.height(14.dp))
        ActionChip("Speichern") { host.saveTimetableDraft() }
        Spacer(Modifier.height(16.dp))
    }
}
