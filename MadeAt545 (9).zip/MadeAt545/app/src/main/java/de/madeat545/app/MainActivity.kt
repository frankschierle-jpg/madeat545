package de.madeat545.app

import android.Manifest
import android.app.DatePickerDialog
import android.app.NotificationManager
import android.app.TimePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File
import java.time.LocalDate
import java.time.LocalTime

class MainActivity : ComponentActivity() {

    lateinit var store: Store

    /** 0 Heute · 1 To-Dos · 2 Streak · 3 Einstellungen */
    val tab = mutableIntStateOf(0)

    /** Geöffneter Stundenplan-Entwurf (null = Editor zu). */
    val timetableDraft = mutableStateOf<Timetable?>(null)
    val draftWeek = mutableStateOf(WeekType.A)
    val ocrMessage = mutableStateOf("")

    // Essen
    val foodSearchOpen = mutableStateOf(false)
    val foodResults = mutableStateOf<List<Food>>(emptyList())
    val foodPick = mutableStateOf<Food?>(null)
    val foodPhoto = mutableStateOf<String?>(null)
    val foodMessage = mutableStateOf("")
    private var foodPhotoFile: File? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    private var photoFile: File? = null
    private var photoStartedAt = 0L
    private var timetablePhoto: File? = null

    private val takeBed = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && BedPhoto.isValid(photoFile, photoStartedAt)) {
            BedPhoto.accept(this)
            Toast.makeText(this, "Bett gemacht – abgehakt!", Toast.LENGTH_SHORT).show()
        } else {
            photoFile?.delete()
            Toast.makeText(this, "Kein Foto erkannt – versuch es nochmal.", Toast.LENGTH_SHORT).show()
        }
        photoFile = null
    }

    private val takeTimetable = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = timetablePhoto
        if (!ok || f == null || !f.exists()) {
            ocrMessage.value = "Kein Foto aufgenommen."
            return@registerForActivityResult
        }
        ocrMessage.value = "Stundenplan wird gelesen …"
        TimetableOcr.recognize(this, Uri.fromFile(f)) { result -> applyOcr(result) }
    }

    private val takeFood = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = foodPhotoFile
        foodPhoto.value = if (ok && f != null && f.exists() && f.length() > 0) f.absolutePath else null
    }

    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        Store.version.intValue++
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        savedInstanceState?.getString("photo")?.let { photoFile = File(it) }
        savedInstanceState?.getString("ttphoto")?.let { timetablePhoto = File(it) }
        photoStartedAt = savedInstanceState?.getLong("started") ?: 0L
        tab.intValue = intent?.getIntExtra("tab", 0) ?: 0
        Notifications.createChannels(this)
        AlarmScheduler.scheduleAll(this)
        if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission()) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { MadeTheme { AppRoot() } }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (intent.hasExtra("tab")) tab.intValue = intent.getIntExtra("tab", 0)
    }

    override fun onResume() {
        super.onResume()
        AlarmScheduler.scheduleAll(this)
        if (AlarmService.isRinging) {
            startActivity(Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        Store.version.intValue++ // Daten neu lesen (z. B. nach dem Wecker)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        photoFile?.let { outState.putString("photo", it.absolutePath) }
        timetablePhoto?.let { outState.putString("ttphoto", it.absolutePath) }
        outState.putLong("started", photoStartedAt)
    }

    // ---------- Aktionen ----------
    fun takeBedPhoto() {
        val f = BedPhoto.newFile(this)
        photoFile = f
        photoStartedAt = System.currentTimeMillis()
        try {
            takeBed.launch(BedPhoto.uriFor(this, f))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Keine Kamera-App gefunden.", Toast.LENGTH_SHORT).show()
        }
    }

    fun toggle(date: LocalDate, id: String, value: Boolean) = store.setDone(date, id, value)

    fun nextRecipe(date: LocalDate) = store.setRecipeIndex(date, store.recipeIndex(date) + 1)

    fun switchWeek() { store.weekOffset = store.weekOffset + 1 }

    fun setWakeOnce(date: LocalDate, t: LocalTime?) {
        store.setWakeOverride(date, t)
        AlarmScheduler.scheduleWake(this)
    }

    fun setWakeDefault(t: LocalTime) {
        store.wakeDefault = t
        AlarmScheduler.scheduleWake(this)
    }

    fun setWakeDay(day: java.time.DayOfWeek, t: LocalTime?) {
        store.setWakeForDay(day, t)
        AlarmScheduler.scheduleWake(this)
    }

    fun testAlarm() {
        AlarmScheduler.scheduleTest(this, 60)
        Toast.makeText(this, "Test-Wecker klingelt in 1 Minute. Handy ruhig sperren.", Toast.LENGTH_LONG).show()
    }

    fun saveTodo(t: Todo) {
        store.upsertTodo(t)
        AlarmScheduler.scheduleTodos(this)
    }

    fun deleteTodo(t: Todo) {
        AlarmScheduler.cancelTodo(this, t)
        store.deleteTodo(t.id)
    }

    fun completeTodo(t: Todo, value: Boolean) {
        AlarmScheduler.cancelTodo(this, t)
        store.completeTodo(t, value)
        AlarmScheduler.scheduleTodos(this)
    }

    fun pickDate(initial: LocalDate?, onPicked: (LocalDate) -> Unit) {
        val d = initial ?: LocalDate.now()
        DatePickerDialog(this, { _, y, m, day -> onPicked(LocalDate.of(y, m + 1, day)) }, d.year, d.monthValue - 1, d.dayOfMonth).show()
    }

    fun pickTime(initial: LocalTime?, onPicked: (LocalTime) -> Unit) {
        val t = initial ?: LocalTime.of(15, 0)
        TimePickerDialog(this, { _, h, m -> onPicked(LocalTime.of(h, m)) }, t.hour, t.minute, true).show()
    }

    // ---------- Essen ----------
    fun scanBarcode() {
        foodMessage.value = ""
        val options = com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(
                com.google.mlkit.vision.barcode.common.Barcode.FORMAT_EAN_13,
                com.google.mlkit.vision.barcode.common.Barcode.FORMAT_EAN_8,
                com.google.mlkit.vision.barcode.common.Barcode.FORMAT_UPC_A,
                com.google.mlkit.vision.barcode.common.Barcode.FORMAT_UPC_E,
            )
            .build()
        com.google.mlkit.vision.codescanner.GmsBarcodeScanning.getClient(this, options).startScan()
            .addOnSuccessListener { barcode ->
                val code = barcode.rawValue
                if (code.isNullOrBlank()) {
                    foodMessage.value = "Barcode nicht lesbar – versuch es nochmal."
                } else {
                    foodMessage.value = "Suche Produkt …"
                    Thread {
                        val food = OpenFoodFacts.byBarcode(code)
                        main.post {
                            if (food == null) {
                                foodMessage.value = "Produkt nicht gefunden (oder kein Internet). Such es einfach per Name."
                            } else {
                                foodMessage.value = ""
                                foodPhoto.value = null
                                foodPick.value = food
                            }
                        }
                    }.start()
                }
            }
            .addOnFailureListener {
                foodMessage.value = "Scanner konnte nicht starten. Sind die Google-Play-Dienste aktuell?"
            }
    }

    fun searchFoodLocal(q: String) {
        foodResults.value = BasicFoods.search(q)
    }

    fun searchFoodOnline(q: String) {
        if (q.isBlank()) return
        foodMessage.value = "Suche online …"
        Thread {
            val online = OpenFoodFacts.search(q)
            main.post {
                foodResults.value = BasicFoods.search(q) + online
                foodMessage.value = if (online.isEmpty()) "Online nichts gefunden (oder kein Internet)." else ""
            }
        }.start()
    }

    fun takeFoodPhoto() {
        val dir = File(filesDir, "bed").apply { mkdirs() }
        val f = File(dir, "essen_${System.currentTimeMillis()}.jpg")
        foodPhotoFile = f
        try {
            takeFood.launch(BedPhoto.uriFor(this, f))
        } catch (_: ActivityNotFoundException) {
            Toast.makeText(this, "Keine Kamera-App gefunden.", Toast.LENGTH_SHORT).show()
        }
    }

    fun addFood(food: Food, grams: Double, meal: Meal) {
        store.addFood(FoodEntry(System.currentTimeMillis(), LocalDate.now(), meal, food, grams, foodPhoto.value))
        store.rememberFood(food)
        foodPick.value = null
        foodPhoto.value = null
        foodResults.value = emptyList()
    }

    fun cancelFood() {
        foodPick.value = null
        foodPhoto.value = null
    }

    // ---------- Stundenplan ----------
    fun openTimetableEditor() {
        val today = LocalDate.now()
        val current = store.timetableFor(today)
        // Vorschlag: neuer Plan gilt ab dem nächsten Montag
        var start = today.plusDays(1)
        while (start.dayOfWeek != java.time.DayOfWeek.MONDAY) start = start.plusDays(1)
        timetableDraft.value = current.copy(validFrom = start)
        draftWeek.value = Schedule.weekType(today, store.weekOffset)
        ocrMessage.value = ""
    }

    fun closeTimetableEditor() { timetableDraft.value = null }

    fun saveTimetableDraft() {
        val d = timetableDraft.value ?: return
        store.saveTimetable(d)
        timetableDraft.value = null
        AlarmScheduler.scheduleAll(this)
        Toast.makeText(this, "Stundenplan gespeichert – gilt ab ${d.validFrom.dayOfMonth}.${d.validFrom.monthValue}.", Toast.LENGTH_LONG).show()
    }

    fun photographTimetable() {
        val dir = File(filesDir, "bed").apply { mkdirs() }
        val f = File(dir, "stundenplan_${System.currentTimeMillis()}.jpg")
        timetablePhoto = f
        try {
            takeTimetable.launch(BedPhoto.uriFor(this, f))
        } catch (_: ActivityNotFoundException) {
            ocrMessage.value = "Keine Kamera-App gefunden."
        }
    }

    private fun applyOcr(result: TimetableOcr.Result?) {
        val draft = timetableDraft.value
        if (result == null || draft == null) {
            ocrMessage.value = "Der Stundenplan konnte nicht gelesen werden. Trag die Zeiten bitte von Hand ein."
            return
        }
        if (result.endTimes.isEmpty()) {
            val times = result.allTimes.joinToString(", ") { it.toString() }
            ocrMessage.value = if (times.isEmpty()) {
                "Keine Uhrzeiten erkannt. Trag das Schulende bitte von Hand ein."
            } else {
                "Gefundene Uhrzeiten: $times. Die Wochentage konnte ich nicht zuordnen – bitte tippe das Schulende pro Tag an."
            }
            return
        }
        val week = draftWeek.value
        timetableDraft.value = if (week == WeekType.A) draft.copy(endA = draft.endA + result.endTimes)
        else draft.copy(endB = draft.endB + result.endTimes)
        val names = mapOf(
            java.time.DayOfWeek.MONDAY to "Mo", java.time.DayOfWeek.TUESDAY to "Di", java.time.DayOfWeek.WEDNESDAY to "Mi",
            java.time.DayOfWeek.THURSDAY to "Do", java.time.DayOfWeek.FRIDAY to "Fr",
        )
        val found = result.endTimes.entries.sortedBy { it.key }.joinToString(", ") { "${names[it.key]} ${it.value}" }
        ocrMessage.value = "Erkannt für die $week-Woche: $found. Bitte prüfen und falls nötig antippen und korrigieren."
    }

    // ---------- Berechtigungen ----------
    fun hasNotificationPermission(): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    fun canFullScreen(): Boolean =
        if (Build.VERSION.SDK_INT >= 34) getSystemService(NotificationManager::class.java).canUseFullScreenIntent() else true

    fun ignoresBattery(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33 && !hasNotificationPermission()) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else openAppSettings()
    }

    fun requestFullScreen() {
        if (Build.VERSION.SDK_INT >= 34) {
            safeStart(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
        }
    }

    fun requestExact() {
        if (Build.VERSION.SDK_INT >= 31) {
            safeStart(Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:$packageName")))
        }
    }

    @android.annotation.SuppressLint("BatteryLife")
    fun requestBattery() {
        safeStart(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
    }

    private fun openAppSettings() {
        safeStart(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    private fun safeStart(i: Intent) {
        try {
            startActivity(i)
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) { }
        }
    }

    // ---------- Grundgerüst ----------
    @Composable
    private fun AppRoot() {
        val host = this
        Column(
            Modifier
                .fillMaxSize()
                .background(C.Creme)
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            Box(Modifier.weight(1f)) {
                if (timetableDraft.value != null) {
                    TimetableScreen(host)
                } else when (tab.intValue) {
                    0 -> TodayPager(host)
                    1 -> TodosScreen(host)
                    2 -> StreakScreen(host)
                    else -> SettingsScreen(host)
                }
            }
            if (timetableDraft.value == null) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    listOf("Heute", "To-Dos", "Streak", "Mehr").forEachIndexed { i, label ->
                        val selected = tab.intValue == i
                        Box(
                            Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(20.dp))
                                .background(if (selected) C.Sand else C.Beige)
                                .clickable { tab.intValue = i }
                                .padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(label, color = C.Mokka, fontSize = 14.sp, fontWeight = if (selected) FontWeight.Medium else FontWeight.Normal)
                        }
                    }
                }
            }
        }
    }
}
